function init()

    timer = 0
    count = 0
    
end

function draw(dt)

        timer = timer + dt
        if timer > 5 then
            count = count + 1
            timer = 0
        end
        
        if count == 0 then
            UiImage("MOD/pics/morning.png")
        end
        
        if count == 1 then
            UiImage("MOD/pics/day.png")
        end
        
        if count == 2 then
            UiImage("MOD/pics/sunset.png")
        end
        
        if count == 3 then
            UiImage("MOD/pics/night.png")
        end
        
        if count > 3 then
            count = 0
        end
        
    --DebugPrint(timer)
    --DebugPrint(count)
    
end
