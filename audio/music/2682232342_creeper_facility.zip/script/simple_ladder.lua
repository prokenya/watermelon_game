function init()
    
    ladder = FindShape("ladder")
    trigger = FindTrigger("trigger")

end

function tick()

local player = GetPlayerTransform()

    if not IsShapeBroken(ladder) then
        if IsPointInTrigger(trigger, player.pos) and GetPlayerVehicle() == 0 then
            if InputPressed("up") or InputDown("up") then
                SetPlayerVelocity(Vec(0, 5, 0))
            end
            if InputPressed("crouch") or InputDown("crouch") then
                SetPlayerVelocity(Vec(0, 0, 0))
            end
            
        end
    end
end
