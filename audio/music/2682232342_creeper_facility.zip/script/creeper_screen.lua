function init()
	timer = 0
	power = 0
   
end

function draw(dt)
	local alive = GetBool("level.creeper.alive")
    local moving = GetBool("level.creeper.moving")
	if not alive then
        power = 0
	else
		power = 100
	end
	if power < 0 then power = 0 end
	if power > 2400 then power = 2400 end
	UiColor(0.7, 0.6, 0.3)
	UiTranslate(10, 10)
	UiRect(UiWidth()-20, UiHeight()-20)
	UiColor(0,0,0)
	UiTranslate(5, 5)
	UiRect(UiWidth()-30, UiHeight()-30)
	UiColor(0.7, 0.6, 0.3)
	UiTranslate(20, 50)
	UiFont("bold.ttf", 32)
	UiText("CREEPER STATUS:", true)
    UiTranslate(0,50)
	UiText("Maximum health: 100", true)
	UiText("Current health: "..power, true)
	UiTranslate(0, 20)
	if not alive then
        UiColor(1,0,0)
		UiText("DEAD")
    else
        UiColor(0,1,0)
        UiText("ALIVE")
	end	
	UiTranslate(0, 60)
	UiColor(0.7, 0.6, 0.3)
	local w=500
	local h=50
	local fraction = 0.5
	UiRect(w, h)
	UiTranslate(5, 5)
	UiColor(0,0,0)
	UiRect(w-10, h-10)
	UiTranslate(5, 5)
	UiColor(0.7, 0.6, 0.3)
	UiRect((w-20)*(power/100), h-20, 20)
    
end
