function init()
	door = FindShape("door")
	motor = FindJoint("motor")
	sensor = FindTrigger("sensor")
	sound = LoadSound("MOD/sound/pneumatic-door0.ogg")
	min, max = GetJointLimits(motor)
	doorType = GetIntParam("type", 0) -- 0 = Automatic, 1 = Manual, 2 = Locked
	strength = GetFloatParam("strength", 500)
	manualstrenght = GetFloatParam("manualstrength", 250)
	
	isOpen = false
end

function tick(dt)
	local newIsOpen = false
			
	-- Automatic door
	if doorType == 0 then
		if IsPointInTrigger(sensor, GetPlayerPos()) then
			newIsOpen = true
			SetJointMotorTarget(motor, min, 3.5, strength)
		else
			SetJointMotorTarget(motor, max, 3.5, strength)
		end
	end
    if newIsOpen ~= isOpen and IsJointBroken(motor) == false then
		PlaySound(sound, GetShapeWorldTransform(door).pos)
	end
	isOpen = newIsOpen
end