function init()
	vent = FindShape("vent")
    button = FindShape("sanitize_button")
    SetTag(button,"interact","Decontaminate")
    
	sound = LoadLoop("MOD/sound/extinguisher-loop.ogg")
    
    timer = 0
    on=false
end

t=1



function tick(dt)
	--if InputDown('y') then
    
    
	if GetPlayerInteractShape() == button and InputDown("interact") and timer==0 and IsShapeBroken(button) == false then
       
        
        on=true
	
	end
    
    if on==true then
    
        timer = timer + dt
        local smoke = FindLocations("smoke")
        
        for i=1, #smoke do
            local locs = smoke[i]
            local t = GetLocationTransform(locs)
            
            ParticleType("smoke")
            ParticleAlpha(0.4, 0.2, "easeout", 0.02, 0.5)
            ParticleColor(.4, .38, .35, .7, .7, .7)
            ParticleRadius(0.2, 0.3, "easeout")
            ParticleCollide(1, 1, "constant", 0.2)
            SpawnParticle(t.pos, Vec(0,-3,0), 3)
            
            PlayLoop(sound,t.pos)
        end
    end
    
    if timer > 3 then
        timer = 0
        on=false
    end
    --DebugPrint(timer)
end

