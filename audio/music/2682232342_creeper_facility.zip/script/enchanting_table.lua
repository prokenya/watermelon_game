function init()
    
    book = FindBody("book_open")
    book_closed = FindBody("book_closed")
    enchant = FindShape("enchant")
    trigger = FindTrigger("trigger")

    closed_pos = GetBodyTransform(book_closed).pos
    
    book_pos = GetBodyTransform(book).pos
    book_rot = GetBodyTransform(book).rot
    
    count = 0
    broken = false
    
end

function tick()
    
    local booktransform = GetBodyTransform(book).pos
    local target = GetPlayerTransform().pos
    local rot = QuatLookAt(booktransform, target)
    
    if broken == false then
        if IsShapeBroken(enchant) or IsBodyBroken(book) or IsBodyBroken(book_closed) then
            SetBodyDynamic(book, true)
            SetBodyDynamic(book_closed, true)
            local pos = Vec(0,1,0)
            local imp = Vec(0,0,0)
            ApplyBodyImpulse(book, pos, imp)
            ApplyBodyImpulse(book_closed, pos, imp)
            broken = true
        else
            if IsPointInTrigger(trigger, target) then
                SetBodyTransform(book, Transform(book_pos))
                SetBodyTransform(book_closed, Transform(closed_pos))
                SetBodyTransform(book, Transform(book_pos, rot))
                
            else
                
                count = count + 0.5
                SetBodyTransform(book, Transform(closed_pos))
                SetBodyTransform(book_closed, Transform(book_pos, QuatEuler(0, count, 0)))
                SetBodyTransform(book, Transform(closed_pos))
            end
        end
    end
    
    if count > 360 then
        count = 0
    end
    
    --DebugPrint(count)
    
end
