function init()
	frozen = {}
	freeze = false

	keybind = "q"
end

function tick(dt)
	if InputPressed(keybind) then
		freeze = not freeze
	end
end

function update(dt)
	if freeze then
		local bodies = FindBodies(nil, true)
		for i=1, #bodies do
			if not frozen[bodies[i]] then
				frozen[bodies[i]] = {velocity = GetBodyVelocity(bodies[i]), angVelocity = GetBodyAngularVelocity(bodies[i]), body = bodies[i]}
			elseif GetPlayerGrabBody() ~= bodies[i] then
				local record = frozen[bodies[i]]
				frozen[bodies[i]] = {velocity = VecAdd(record.velocity, GetBodyVelocity(bodies[i])), angVelocity = VecAdd(record.angVelocity, GetBodyAngularVelocity(bodies[i])), body = bodies[i]}
			end
		end

		for bodyhash, record in pairs(frozen) do
			if record then
				SetBodyVelocity(record.body, Vec(0,0,0))
				SetBodyAngularVelocity(record.body, Vec(0,0,0))
				ApplyBodyImpulse(record.body,TransformToParentPoint(GetBodyTransform(record.body),GetBodyCenterOfMass(record.body)),Vec(0,GetBodyMass(record.body)*dt*10,0))
			end
		end
	end

	if not freeze then
		for bodyhash, record in pairs(frozen) do
			SetBodyVelocity(record.body, record.velocity)
			SetBodyAngularVelocity(record.body, record.angVelocity)
		end

		frozen = {}
	end
end

function draw() 
	if freeze then
		UiColor(1, 1, 1)
		UiTranslate(30, 30)
		UiRect(10, 60)
		UiTranslate(40, 0)
		UiRect(10, 60)
	end
end