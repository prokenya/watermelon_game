local maxUses = 150
local currentUses = maxUses
local shootPointOffset = Vec(0.95, -0.70, -2.3)

function init()
    RegisterTool("grapplehook", "Веб-Шутер", "MOD/vox/grapplehook.vox")
    SetBool("game.tool.grapplehook.enabled", true)
    SetFloat("game.tool.grapplehook.ammo", currentUses)

    hooked = false
    stickToPlayer = false
    grabPhy = GetBool("savegame.mod.grabPhy")
    weaponSwitch = GetBool("savegame.mod.weaponSwitch")
    t = GetCameraTransform()

    shootPoint = TransformToParentPoint(t, shootPointOffset)

    chaosTimer = 0
end

local hookHitSound = LoadSound("MOD/snd/thwip.ogg")

function GetAimPos()
    local forward = TransformToParentVec(t, Vec(0, 0, -1))
    local hit, dist, _, shape = QueryRaycast(t.pos, forward, 100)
    return VecAdd(t.pos, VecScale(forward, dist)), dist, hit, shape
end

function Hook()
    local aimpos, dist, hit, shape = GetAimPos()

    local maxDistance = 35
    if dist > maxDistance then return end

    if hit then
        hitbody = GetShapeBody(shape)
        hit_pos = aimpos
        localhitpos = TransformToLocalPoint(GetBodyTransform(hitbody), hit_pos)
        hit_dist = dist
        hooked = true
        stickToPlayer = false
        PlaySound(hookHitSound, aimpos, 0.5)
        currentUses = currentUses - 1
        SetFloat("game.tool.grapplehook.ammo", currentUses)
        chaosTimer = 1
    end
end

function rndVec(length)
    return VecScale(VecNormalize(Vec(math.random(-100, 100), math.random(-100, 100), math.random(-100, 100))), length)
end

function StickToSurface(point, offset)
    local _, _, normal = QueryRaycast(point, offset, 2)
    return VecAdd(point, VecScale(normal, 0.1))
end

function Pull(pullpower, vel_scale)
    local direction = VecNormalize(VecSub(hit_pos, t.pos))
    local velocity = GetPlayerVelocity()
    local scale_vel = VecScale(velocity, vel_scale)

    local force = VecScale(direction, pullpower / (VecLength(scale_vel) + 1))
    local pullVelocity = VecAdd(velocity, force)

    local maxPullSpeed, maxStretchSpeed = 15, 20
    local currentPullSpeed = VecLength(pullVelocity)
    local maxSpeed = currentPullSpeed > maxStretchSpeed and maxStretchSpeed or maxPullSpeed

    if currentPullSpeed > maxSpeed then
        pullVelocity = VecScale(VecNormalize(pullVelocity), maxSpeed)
    end

    SetPlayerVelocity(pullVelocity)
end

function drawCone(startPos, endPos, radius, segments)
    local color = {105, 105, 105}
    local height = VecLength(VecSub(endPos, startPos))
    local angleIncrement = 2 * math.pi / segments

    for i = 1, segments, 2 do 
        local angle1 = angleIncrement * (i - 1)
        local angle2 = angleIncrement * i

        local x1 = radius * math.cos(angle1)
        local y1 = radius * math.sin(angle1)
        local x2 = radius * math.cos(angle2)
        local y2 = radius * math.sin(angle2)

        local p1 = VecAdd(startPos, Vec(x1, y1, 0))
        local p2 = VecAdd(startPos, Vec(x2, y2, 0))
        local p3 = VecAdd(endPos, Vec(0, 0, height))

        p1 = StickToSurface(p1, VecScale(VecNormalize(VecSub(startPos, endPos)), 0.2))
        p2 = StickToSurface(p2, VecScale(VecNormalize(VecSub(startPos, endPos)), 0.2))
        p3 = StickToSurface(p3, VecScale(VecNormalize(VecSub(startPos, endPos)), 0.2))

        DrawLine(p1, p2, color[1], color[2], color[3])
        DrawLine(p2, p3, color[1], color[2], color[3])
    end

    drawIcosahedron(endPos, 0.1, 8)
end

function drawIcosahedron(center, radius, segments)
    local color = {105, 105, 105}

    local t = (1 + math.sqrt(5)) / 2

    local vertices = {
        Vec(-1, t, 0),
        Vec(1, t, 0),
        Vec(-1, -t, 0),
        Vec(1, -t, 0),
        Vec(0, -1, t),
        Vec(0, 1, t),
        Vec(0, -1, -t),
        Vec(0, 1, -t),
        Vec(t, 0, -1),
        Vec(t, 0, 1),
        Vec(-t, 0, -1),
        Vec(-t, 0, 1)
    }

    local edges = {
        {1, 12}, {6, 2}, {8, 11}, {10, 6}, {12, 5},
        {11, 3}, {8, 7}, {2, 9}, {4, 10}, {5, 3},
        {7, 9}, {4, 5}, {3, 12}, {7, 8}, {9, 10},
        {1, 6}, {1, 2}, {1, 8}, {1, 11}
    }

    for _, edge in ipairs(edges) do
        local p1 = VecAdd(center, VecScale(vertices[edge[1]], radius))
        local p2 = VecAdd(center, VecScale(vertices[edge[2]], radius))
        DrawLine(p1, p2, color[1], color[2], color[3])
    end

    for i = 1, #vertices, 2 do
        local p1 = VecAdd(center, VecScale(vertices[i], radius))
        local p2 = VecAdd(center, VecScale(vertices[i + 1], radius))
        DrawLine(p1, p2, color[1], color[2], color[3])
    end
end

function tick(dt)
    t = GetCameraTransform()

    if GetString("game.player.tool") == "grapplehook" then
        local forward = TransformToParentVec(t, Vec(0, 0, -1))
        if InputPressed("lmb") then
            if not hooked and currentUses > 0 then
                Hook()
            elseif hooked then
                hooked = false
            end
        elseif InputReleased("lmb") and hooked then
            hooked = false
        end
    elseif not weaponSwitch then
        hooked = false
    end

    if hooked then
        if grabPhy then hit_pos = TransformToParentPoint(GetBodyTransform(hitbody), localhitpos) end
        local tool = GetBodyTransform(GetToolBody())
        local zero = Vec(0, 0, 0)
        local tool_pos = TransformToParentPoint(tool, shootPointOffset)
        local h = TransformToLocalPoint(tool, hit_pos)
        local direction = VecNormalize(VecSub(h, zero))

        if GetString("game.player.tool") == "grapplehook" then SetToolTransform(Transform(zero, QuatLookAt(zero, direction))) end

        local last, points = tool_pos, 10 
        for i = 1, points do
            local t = i / points
            local p

            if chaosTimer > 0 then
                p = VecLerp(tool_pos, hit_pos, t)
                p = VecAdd(p, rndVec(0.1))
                chaosTimer = math.max(0, chaosTimer - dt)
            else
                p = VecLerp(tool_pos, hit_pos, t)
                p = StickToSurface(p, VecScale(direction, 0.2))
            end

            DrawLine(last, p, 105, 105, 105)
            last = p
        end

        local dist = VecLength(VecSub(hit_pos, t.pos))

        if InputDown("rmb") then
            stickToPlayer = true
            Pull(8, 0.9)
        end

        if dist > 8 and not stickToPlayer then
            Pull(2 + ((dist - 8) * 0.02), 0.52)
        end

        drawCone(last, hit_pos, 0.1, 8)
    end
end