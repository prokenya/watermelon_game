function init()
    SetBool("savegame.mod.grabPhy", true)
end

function draw()
	UiTranslate(UiCenter(), 350)
	UiAlign("center middle")

	UiFont("regular.ttf", 26)
	UiTranslate(0, 70)
	UiPush()
		UiAlign("center")
		local phy = GetBool("savegame.mod.grabPhy")
		local text = "Yes"
		if phy then UiColor(0.1, 0.7, 1) else UiColor(1, 0.2, 0.2) end
		if not phy then text = "No" end
		
		if UiTextButton("Web on dynamic objects: "..text) then
			SetBool("savegame.mod.grabPhy", not phy)
		end
	UiPop()

	UiTranslate(0, 90)
	UiPush()
		UiAlign("center")
		local weapon = GetBool("savegame.mod.weaponSwitch")
		local text = "Yes"
		if weapon then UiColor(0.1, 0.7, 1) else UiColor(1, 0.2, 0.2) end
		if not weapon then text = "No" end
		
		if UiTextButton("Web after switching tool: "..text) then
			SetBool("savegame.mod.weaponSwitch", not weapon)
		end
	UiPop()

	UiButtonImageBox("ui/common/box-outline-6.png", 6, 6)

	UiTranslate(0, 100)
	if UiTextButton("Close", 80, 40) then
		Menu()
	end
end