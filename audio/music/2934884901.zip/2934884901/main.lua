rocketprojectileHandler = {
	shellNum = 1,
	shells = {},
	defaultShell = {active = false, strength = 50.5, maxDist = 70000.5, maxMass = 1500000}
}

function isItemInTable(item,listing) --for duplicate bodys in tables
	local listed = false
	
	for i,k in ipairs(listing) do
		if k == item then listed = true end --found
	end
	
	if listed then return true else return false end
end

muzzleflash = LoadSprite("gfx/glare.png")

function init()
	RegisterTool("HaloFuelRod", "Halo: Infinity Fuel Rod", "MOD/vox/HaloFuelRod.vox", 3)
	SetBool("game.tool.HaloFuelRod.enabled", true)
	SetFloat("game.tool.HaloFuelRod.ammo", 999999)

	rocketgravity = Vec(0, -10, 0)
	velocity = 0.8
	reloadTime = 1
	ammo = 5
	mags = 40
	reloading = false
	unlimitedammo = GetBool("savegame.mod.unlimitedammo")

	reloadTimer = 0
	rocketTimer = 0
	recoilTimer = 0
	lightTimer = 0
        unbreakable = false
	damage = 2.6

	for i=1, 250 do
		rocketprojectileHandler.shells[i] = deepcopy(rocketprojectileHandler.defaultShell)
	end
	rocketsound = LoadSound("MOD/snd/bazooka.ogg")
	rocketboomsound = LoadSound("MOD/snd/bazooka_boom.ogg")
	cocksound = LoadSound("MOD/snd/bazooka_cock.ogg")
	reloadsound = LoadSound("MOD/snd/bazooka_reload.ogg")
	dryfiresound = LoadSound("MOD/snd/dryfire.ogg")
	refillsound = LoadSound("MOD/snd/refill.ogg")
end

function rndVec(length)
	local v = VecNormalize(Vec(math.random(-100,100), math.random(-100,100), math.random(-100,100)))
	return VecScale(v, length)	
end

function deepcopy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[deepcopy(orig_key)] = deepcopy(orig_value)
        end
        setmetatable(copy, deepcopy(getmetatable(orig)))
    else
        copy = orig
    end
    return copy
end

function GetAimPos()
	local ct = GetCameraTransform()
	local forwardPos = TransformToParentPoint(ct, Vec(0, 0, -100))
    local direction = VecSub(forwardPos, ct.pos)
    local distance = VecLength(direction)
	local direction = VecNormalize(direction)
	local hit, hitDistance = QueryRaycast(ct.pos, direction, distance)
	if hit then
		forwardPos = TransformToParentPoint(ct, Vec(0, 0, -hitDistance))
		distance = hitDistance
	end
	return forwardPos, hit, distance
end

function Fire()
	if ammo == 0 then
		return
	end

	aimpos, hit, distance = GetAimPos()
	gunpos = TransformToParentPoint(GetCameraTransform(), Vec(0.7, -0.1, -3))
	local direction = VecSub(aimpos, gunpos)

	rocketprojectileHandler.shells[rocketprojectileHandler.shellNum] = deepcopy(rocketprojectileHandler.defaultShell)
	loadedShell = rocketprojectileHandler.shells[rocketprojectileHandler.shellNum] 
	loadedShell.active = true
	loadedShell.pos = gunpos
	loadedShell.predictedBulletVelocity = VecScale(direction, velocity*(100/distance))

	rocketprojectileHandler.shellNum = (rocketprojectileHandler.shellNum%#rocketprojectileHandler.shells) +1
	SpawnParticle("fire", gunpos, Vec(0, 1.0+math.random(1,10)*0.1, 0), 0.3, 0.1)
	SpawnParticle("darksmoke", gunpos, Vec(0, 1.0+math.random(1,10)*0.1, 0), 0.75, 1.5)
	PlaySound(rocketsound, GetPlayerTransform().pos, 0.8, false)
	if not unlimitedammo then
		ammo = ammo - 1
	end
	recoilTimer = 0.3
	lightTimer = 0.15
end

function RandomVector(magnitude)
    local x = Random()
    local y = Random()
    local z = Random()
    return Vec((x - 0.5) * 2 * magnitude, (y - 0.5) * 2 * magnitude, (z - 0.5) * 2 * magnitude)
end

function Random()
    return math.random(0, 1000) / 1000
end


function RocketOperations(projectile)
	projectile.predictedBulletVelocity = VecAdd(projectile.predictedBulletVelocity, (VecScale(rocketgravity, GetTimeStep())))
	local point2 = VecAdd(projectile.pos, VecScale(projectile.predictedBulletVelocity, GetTimeStep()))
	---local dir = VecNormalize(VecSub(point2, projectile.pos))
	local dir = VecSub(aimpos, point2)
	local hit, dist, normal, shape = QueryRaycast(projectile.pos, dir, VecLength(VecSub(point2, projectile.pos)))
	
	if hit then
		hitPos = VecAdd(projectile.pos, VecScale(VecNormalize(VecSub(point2, projectile.pos)), dist))
		hitpoint1 = VecAdd(projectile.pos, VecScale(VecNormalize(VecSub(point2, projectile.pos)), dist+1.5))
		projectile.active = false
		PlaySound(rocketboomsound, hitPos, 10, false)
		

		MakeHole(hitPos, 4, 4, 4)
		explosionLarge(hitPos)
		Paint(hitPos, 5.2, "explosion", 1.3)
                if unbreakable then
		damagexen(hitPos)
		end

			max = 10
			local objectbodies = QueryAabbBodies( VecAdd(hitPos, Vec(-max, -max, -max)), VecAdd(hitPos, Vec(max, max, max)))
            for i = 1, #objectbodies do
                local objectbodies2 = objectbodies[i]
                if IsBodyDynamic(objectbodies2) then
                  local bb, bbba = GetBodyBounds(objectbodies2)
                  local direction = VecSub(VecLerp(bb, bbba, 0.5), hitPos)
                  local distance = VecLength(direction)
                  direction = VecScale(direction, 1 / distance)
                  if distance < max and IsBodyVisible(objectbodies2, max * 100) then --max * 100
                      local distScale = 1 - math.min(distance / max, 0.9)
                      local vel = GetBodyVelocity(objectbodies2)
                      vel = VecAdd(GetBodyVelocity(objectbodies2), VecScale(direction, 30 * distScale)) --50
	
		local voxelCount = GetShapeVoxelCount(voxelCount)
		if voxelCount < 30000 then
                SetBodyVelocity(objectbodies2, vel)
					end

					end
				  end
			   end	

		--holed body
		QueryRequire("physical") --dynamic optional
                --dynamic small optional
		local mi = VecAdd(hitPos,Vec(-damage,-damage,-damage))
		local ma = VecAdd(hitPos,Vec(damage,damage,damage))
		local bodies = QueryAabbBodies(mi, ma)	
		local hitbody = GetShapeBody(hitShape)
		--DebugPrint(isItemInTable(hitbody,bodies))
		if not isItemInTable(hitbody, bodies) then 
			table.insert(bodies, GetShapeBody(hitShape))
		end
		for i,body in ipairs(bodies) do
			--compute body center and dist
			local bmi,bma = GetBodyBounds(body)
			local bc = VecLerp(bmi,bma,0.5) --get center
			local dir = VecSub(bc, hitPos)
			local dist = VecLength(dir)
			dir = VecScale(dir,1/dist)
			local mass = GetBodyMass(body)--get mass
			
			--dir forward
			dir = VecLerp(dir,projectile.predictedBulletVelocity,0.8)
			dir = VecNormalize(dir)

                        --mass and dist scale

			if HasTag(shape,"unbreakable") then
                        unbreakable = true
			end
                        if not HasTag(shape,"unbreakable") then
                        unbreakable = false
                        end
		        end
	else
        local rnd = math.random()*3/4+1
	DrawSprite(muzzleflash,{pos=point2,rot=GetCameraTransform().rot},20,20, 0.25, 1, 0.21, 1, false,true)
	DrawSprite(muzzleflash,{pos=point2,rot=GetCameraTransform().rot},10,10,1,1,1,1,1,1,0.1,false,true)
	

    --spawn sparks
		PointLight(projectile.pos, 0.25,1,0.21, 3)

      --spawn projectile
		ParticleReset()
		ParticleType("plain")
		ParticleTile(6)
		ParticleSticky(0, 0)
		ParticleRadius(0.01, 0.01)
		ParticleAlpha(0.9)
		ParticleEmissive(10, 1)
		ParticleColor(0.25,1,0.21)
		ParticleGravity(-10, -10)
		for i = 1, 20 do
		SpawnParticle(projectile.pos, Vec((math.random(-100,100)/100)*5,(math.random(-100,100)/100)*5, (math.random(-100,100)/100)*5), math.random(10,25)/20)
		end
		
		ParticleReset()
		ParticleTile(6)
		ParticleRotation(50)
		ParticleRadius(0.3)
		ParticleSticky(0,1)
		ParticleColor(0.25,1,0.21)
		ParticleEmissive(10, 1, "easeout")
		ParticleGravity(1)
		ParticleAlpha(1, 0.5)
		ParticleDrag(0, 1)
		ParticleStretch(10)
	for i=1,math.random(1,1) do
		SpawnParticle(projectile.pos,Vec(math.random(-1,1),math.random(-1,1),math.random(-1,1)),0.1)
	end
	end
    projectile.pos = point2
end

function Reload()
	if reloading then
		return
	end
	PlaySound(reloadsound, GetPlayerTransform().pos, 1, false)
	reloading = true
	reloadTimer = reloadTime
end

function damagexen() 
			local t = GetCameraTransform()
			local p = TransformToParentPoint(t, Vec(0, 0, -2))
			local d = VecAdd(TransformToParentVec(t, Vec(0,0,-1)), Vec(0, 0, 0))
			for i=0, 7 do
			Shoot(p, d, "shotgun")
			end
end

function tick(dt)
	if GetString("game.player.tool") == "HaloFuelRod" and GetPlayerVehicle() == 0 then
	scopeAim()
	---DebugCross(TransformToParentPoint(GetCameraTransform(), Vec(0.7, -0.1, -3)))
	SetBool("hud.aimdot", false)
		if InputPressed("lmb") then
			if not reloading then
				if ammo == 0 then
					PlaySound(dryfiresound, GetPlayerTransform().pos, 1, false)
				else
					Fire()
				end
			end
		end

		local b = GetToolBody()
		if b ~= 0 then
			local offset = Transform(Vec(0.4, -0.4, 0.0))
			SetToolTransform(offset)

			if recoilTimer > 0 then
				local t = Transform()
				t.pos = Vec(0.4, -0.4, recoilTimer*3)
				t.rot = QuatEuler(recoilTimer*30, 0, 0)
				SetToolTransform(t)

				recoilTimer = recoilTimer - dt
			end

			if lightTimer > 0 then
				local p = TransformToParentPoint(GetBodyTransform(b), Vec(0, 0, -2))
				PointLight(p, 1, 1, 1, 0.5)

				lightTimer = lightTimer - dt
			end
		end

		if not unlimitedammo then
			if ammo < 1 and mags > 1 and InputPressed("R") then
				Reload()
			end

			if GetBool("ammobox.refill") then
				SetBool("ammobox.refill", false)
				mags = mags + 5
				PlaySound(refillsound, GetPlayerTransform().pos, 1, false)
			end

			if reloading then
				reloadTimer = reloadTimer - dt
				if reloadTimer < 0 then
					PlaySound(cocksound, GetPlayerTransform().pos, 0.75, false)
					ammo = ammo + 5
					mags = mags - 5
					reloadTimer = 0
					reloading = false
				end
			end
		end
	end

	for key, shell in ipairs(rocketprojectileHandler.shells) do
		if shell.active then
			RocketOperations(shell)
		end
	end
end

function impactEffect()
local strength = 100	--Strength of Shotgun Blast
local maxMass = 100000	--The maximum mass for a body to be affected
local maxDist = 100	--The maximum distance for bodies to be affected
	local t = GetCameraTransform()
	local pos = t.pos
	local pos2 = TransformToParentPoint(t, Vec(0, 0, 0))
	local dir1 = TransformToParentVec(t, Vec(0, 0, -1))
	local hit, dist, normal, shape = QueryRaycast(pos, dir1, 1500)
	blastpoint = VecAdd(pos, VecScale(dir1, dist))

	local mi = VecAdd(blastpoint, Vec(-0.8, -0.8, -0.8))
	local ma = VecAdd(blastpoint, Vec(0.8, 0.8, 0.8))
	QueryRequire("physical dynamic")
	local bodies = QueryAabbBodies(mi, ma)
							
	for i=1,#bodies do
		local b = bodies[i]
		local bmi, bma = GetBodyBounds(b)
		local bc = VecLerp(bmi, bma, 0.5)
		local dir = VecSub(bc, blastpoint)
		local dist1 = VecLength(dir)
		dir = VecScale(dir, 1.0/dist1)
		local mass = GetBodyMass(b)
		if mass < maxMass then
			local massScale = 1 - math.min(mass/maxMass, 1.0)
			local distScale = 1 - math.min(dist/maxDist, 1.0)
			local add = VecScale(dir1, (strength/2) * (massScale/2) * (distScale*2))
			local vel = VecScale(dir1, .2)
			vel = VecAdd(vel, add)
			SetBodyVelocity(b, vel)
		end
	end
end

function scopeAim()

    local body = GetPlayerGrabBody()
	local shape = GetPlayerGrabShape()

	if InputDown("rmb") and not reloading and shape == 0 and body == 0 then
	    if scopeSound == 0 then
	        ---PlaySound(gunScopeSound)
			scopeSound = 1
		end
	    SetCameraFov(20)
	end
	
	if not InputDown("rmb") and reloading == 0  then
	    scopeSound = 0
	end
	
end

function shootingORIGINALGOOD()
    max = 100
    t = GetCameraTransform()
    transform = TransformToParentVec(t, Vec(0, 0, -1))
    hit, dist, normal, shape = QueryRaycast(t.pos, transform, 1500)
    pos = VecAdd(t.pos, VecScale(transform, dist))
    local objectbodies = QueryAabbBodies( VecAdd(pos, Vec(-11, -11, -11)), VecAdd(pos, Vec(11, 11, 11)))
    for i = 1, #objectbodies do
        local objectbodies2 = objectbodies[i]
        if IsBodyDynamic(objectbodies2) then
          local bb, bbba = GetBodyBounds(objectbodies2)
          local direction = VecSub(VecLerp(bb, bbba, 0.5), pos)
          local distance = VecLength(direction)
          direction = VecScale(direction, 0.5 / distance)             
          if distance < max and IsBodyActive(objectbodies2, max * 500)then
              local distScale = 1 - math.min(distance / max, 1.0)
              local vel = GetBodyVelocity(objectbodies2)
              vel = VecAdd(GetBodyVelocity(objectbodies2), VecScale(direction, 55 * distScale))
              SetBodyVelocity(objectbodies2, vel)
          end
        end
    end
end


function shooting6()
    max = 100
    t = GetCameraTransform()
    transform = TransformToParentVec(t, Vec(0, 0, -1))
    hit, dist, normal, shape = QueryRaycast(t.pos, transform, 1500)
    pos = VecAdd(t.pos, VecScale(transform, dist))
    local objectbodies = QueryAabbBodies( VecAdd(pos, Vec(-11, -11, -11)), VecAdd(pos, Vec(11, 11, 11)))
    for i = 1, #objectbodies do
        local objectbodies2 = objectbodies[i]
        if IsBodyDynamic(objectbodies2) then
          local bb, bbba = GetBodyBounds(objectbodies2)
          local direction = VecSub(VecLerp(bb, bbba, 0.5), pos)
          local distance = VecLength(direction)
          direction = VecScale(direction, 1 / distance)             
          if distance < max and IsBodyActive(objectbodies2, max * 500)then
              local distScale = 1 - math.min(distance / max, 1.0)
              local vel = GetBodyVelocity(objectbodies2)
              vel = VecAdd(GetBodyVelocity(objectbodies2), VecScale(direction, 10 * distScale))
              SetBodyVelocity(objectbodies2, vel)
          end
        end
    end
end

function shooting5()
    max = 100
    local objectbodies = QueryAabbBodies( VecAdd(pos, Vec(-11, -11, -11)), VecAdd(pos, Vec(11, 11, 11)))
    for i = 1, #objectbodies do
        local objectbodies2 = objectbodies[i]
        if IsBodyDynamic(objectbodies2) then
          local bb, bbba = GetBodyBounds(objectbodies2)
          local direction = VecSub(VecLerp(bb, bbba, 0.5), pos)
          local distance = VecLength(direction)
          direction = VecScale(direction, 1 / distance)             
          if distance < max and IsBodyActive(objectbodies2, max * 500)then
              local distScale = 1 - math.min(distance / max, 1.0)
              local vel = GetBodyVelocity(objectbodies2)
              vel = VecAdd(GetBodyVelocity(objectbodies2), VecScale(direction, 10 * distScale))
              SetBodyVelocity(objectbodies2, vel)
          end
        end
    end
end


function shooting7()
    max = 100
    t = GetCameraTransform()
    transform = TransformToParentVec(t, Vec(0, 0, -1))
    hit, dist, normal, shape = QueryRaycast(t.pos, transform, 1500)
    pos = VecAdd(t.pos, VecScale(transform, dist))
    local objectbodies = QueryAabbBodies( VecAdd(pos, Vec(-11, -11, -11)), VecAdd(pos, Vec(11, 11, 11)))
    for i = 1, #objectbodies do
        local objectbodies2 = objectbodies[i]
        if IsBodyDynamic(objectbodies2) then
          local bb, bbba = GetBodyBounds(objectbodies2)
          local direction = VecSub(VecLerp(bb, bbba, 0.5), pos)
          local distance = VecLength(direction)
          direction = VecScale(direction, 0.5 / distance)             
          if distance < max and IsBodyActive(objectbodies2, max * 500)then
              local distScale = 1 - math.min(distance / max, 1.0)
              local vel = GetBodyVelocity(objectbodies2)
              vel = VecAdd(GetBodyVelocity(objectbodies2), VecScale(direction, 100))
              SetBodyVelocity(objectbodies2, vel)
          end
        end
    end
end

function rnd(mi, ma)
	return math.random(1000)/1000*(ma-mi) + mi
end

function rndVec(t)
	return Vec(rnd(-t, t), rnd(-t, t), rnd(-t, t))
end

trails = {}

function trailsAdd(hitPos, vel, life, size, damp, gravity)
	t = {}
	t.pos = VecCopy(hitPos)
	t.vel = VecAdd(Vec(0, vel*.6, 0), rndVec(vel))
	t.size = size 
	t.age = 0
	t.damp = damp
	t.gravity = gravity
	t.life = rnd(life*1.7, life*1.7)
	t.nextSpawn = 0
	trails[#trails+1] = t
end

function trailsUpdate(dt)
	for i=#trails,1,-1 do
		local t = trails[i]
		t.vel[2] = t.vel[2] + t.gravity*dt
		t.vel = VecScale(t.vel, t.damp)
		t.pos = VecAdd(t.pos, VecScale(t.vel, dt))
		t.age = t.age + dt
		local q = 1.36 - t.age / t.life
		if q > .1 then
			local r = t.size * q + 0.1	
			local spawnRate = 0.9*r/VecLength(t.vel)
			while t.nextSpawn < t.age do
				local w = .20-q*.10
				local w2 = .8
				local v = VecScale(t.vel, .3)
				ParticleReset()
				ParticleType("smoke")
				ParticleColor(w, w*0.95, w*0.9, w2, w2*0.95, w2*0.9)
				ParticleRadius(r)
				ParticleAlpha(q, 0)
				ParticleDrag(2)
				SpawnParticle(t.pos, v, rnd(.4, 2.0))
				t.nextSpawn = t.nextSpawn + spawnRate
			end
		else
			trails[i] = trails[#trails]
			trails[#trails] = nil
		end
	end
end

smoke = {}
smoke.age = 0
smoke.size = 1.1
smoke.life = 1.6
smoke.next = 0
smoke.vel = 0
smoke.gravity = 0
smoke.amount = 2.5
function smokeUpdate(hitPos, dt)
	smoke.age = smoke.age + dt
	if smoke.age < smoke.life then
		local q = 1.0 - smoke.age / smoke.life
		for i=1, smoke.amount*q do
			local w = 0.8-q*0.6
			local w2 = 1.0
			local r = smoke.size*(0.5 + 0.5*q)
			local v = VecAdd(Vec(0, 1*q+q*smoke.vel, 0), rndVec(1*q))
			local p = VecAdd(hitPos, rndVec(r*0.3))
			ParticleReset()
			ParticleType("smoke")
			ParticleColor(w, w*0.95, w*0.9, w2, w2*0.95, w2*0.9)
			ParticleRadius(0.5*r, r)
			ParticleGravity(rnd(0,smoke.gravity))
			ParticleDrag(1.0)
			ParticleAlpha(q, q, "constant", 0, 0.5)
			---SpawnParticle(p, v, rnd(3,5))
		end
	end
end


fire = {}
fire.age = 0
fire.life = 3
fire.size = 2
function fireUpdate(hitPos, dt)
	fire.age = fire.age + dt
	if fire.age < fire.life then
		local q = 1.0 - fire.age / fire.life
		for i=1, 16 do
			local v = VecAdd(Vec(0, 1*i+i*smoke.vel, 0), rndVec(1*i))
			local p = hitPos
			local life = rnd(0.2, 0.7)
			life = 0.5 + life*life*life * 1.5
			ParticleReset()
			ParticleColor(0.84, 0.62, 1.1, 0.71, 0.42, 1.1)
			ParticleAlpha(1, 0)
			ParticleRadius(fire.size*q, 0.8*fire.size*q)
			ParticleGravity()
			ParticleDrag(0.6)
			ParticleEmissive(rnd(2, 5), 0, "easeout")
			ParticleTile(5)
			---SpawnParticle(hitPos, v, life)
		end
	end
end

flash = {}
flash.age = 0
flash.life = 2
flash.intensity = 10
function flashUpdate(hitPos, dt)
	flash.age = flash.age + dt
	if flash.age < flash.life then
		local q = 1.0 - flash.age / flash.life
		PointLight(hitPos, 0.25,1,0.21, flash.intensity*q) 
	end
end
		---PointLight(hitPos, .130, .20, .255, flash.intensity*q) 
		---PointLight(hitPos, .0121, .21, .255, light.intensity*l)

light = {}
light.age = 0
light.life = 1.15
light.intensity = 40
function lightUpdate(hitPos, dt)
	light.age = light.age + dt
	if light.age < light.life then
		local q = 1.0 - light.age / light.life
		local l = q * q
		local p = VecAdd(hitPos, rndVec(0.5*l))
		PointLight(hitPos, 0.22,1.1,0.21, light.intensity*l)
	end
end


function explosionSparks(count, vel)
	for i=1, count do
		local v = VecAdd(Vec(0, vel, 0 ), rndVec(rnd(vel*0.25, vel*1.15)))
		local life = rnd(0, 1)
		life = life*life * 11
		ParticleReset()
		ParticleEmissive(8.5, 8.5, "easeout")
		ParticleGravity(-7)
		ParticleRadius(0.025, 0.0, "easein")
		ParticleColor(28.3, 0.35, 0.28)
		ParticleTile(6)
		SpawnParticle(hitPos, v, life)
	end
end


function explosionDebris(count, vel)
	for i=1, count do
		local r = rnd(0, 1)
		life = 21 + r*r*r*3
		r = (0.4 + 0.6*r*r*r)
		local v = VecAdd(Vec(0, r*vel*1.8, 0), VecScale(rndVec(1), r*vel))
		local radius = rnd(0.05, 0.05)
		local w = rnd(0.4, 0.7)
		ParticleReset()
		ParticleColor(w, w, w)
		ParticleAlpha(1)
		ParticleGravity(-7)
		ParticleRadius(radius, radius, "constant", -11, 11.5)
		ParticleSticky(0.09)
		ParticleStretch(0.0)
		ParticleTile(6)
		ParticleRotation(rnd(-17, 17), 0.0, "easeout")
		SpawnParticle(explosionPos, v, life)
	end
end

function explosionSmall(pos)
	explosionPos = pos
	explosionSparks(25, 2)
	explosionDebris(35, 6)

	trails = {}
	for i=1, 15 do
		trailsAdd(pos, 10, 0.4, 0.13, 0.99, -15)
	end

	flash.age = 0
	flash.life = 0.5
	flash.intensity = 100
	
	light.age = 0
	light.life = 0.9
	light.intensity = 1000
	
	fire.age = 0
	fire.life = 1.5
	fire.size = 0.6
	
	smoke.age = 0
	smoke.life = 10
	smoke.size = 0.7
	smoke.vel = 0
	smoke.gravity = 0
	smoke.amount = 1.7
end


function explosionMedium(pos)
	explosionPos = hitPos
	explosionSparks(260, 3)
	explosionDebris(330, 7)

	trails = {}
	for i=1, 49 do
		trailsAdd(pos, 20, 0.4, .2, .98, -15)
	end

	flash.age = 0
	flash.life = 1.2
	flash.intensity = 150
	
	light.age = 0
	light.life = 1.0
	light.intensity = 2000
	
	fire.age = 0
	fire.life = 5
	fire.size = 1.3

	smoke.age = 0
	smoke.life = 13.5
	smoke.size = 0.85
	smoke.vel = 3.3
	smoke.gravity = 0
	smoke.amount = 5.6
end


function explosionLarge(pos)
	explosionPos = pos
	explosionSparks(360, 5)
	explosionDebris(530, 10)

	trails = {}
	for i=1, 69 do
		trailsAdd(pos, 25, 0.4, 0.2, 0.98, -15)
	end

	flash.age = 0
	flash.life = 1.3
	flash.intensity = 150
	
	light.age = 0
	light.life = 1.1
	light.intensity = 2000
	
	fire.age = 0
	fire.life = 2
	fire.size = 1.4
	
	smoke.age = 0
	smoke.life = 17.5
	smoke.size = .88
	smoke.gravity = 0
	smoke.vel = 3.5
	smoke.amount = 6.5
	
	--Sideways fast cloud
	ParticleReset()
	ParticleColor(0.8, 0.75, 0.7)
	ParticleRadius(0.5, 1.3)
	ParticleAlpha(1, 0, "easeout")
	ParticleDrag(0.2)
	for a=0, math.pi*2, 0.05 do
		local x = math.cos(a)*1
		local y = rnd(-0.1, 0.1)
		local z = math.sin(a)*1
		local d = VecNormalize(Vec(x, y, z))
		SpawnParticle(VecAdd(pos, d), VecScale(d, rnd(8,12)), rnd(0.5, 1.5))
	end
end

function update(dt)
	trailsUpdate(dt)
	fireUpdate(hitPos, dt)
	smokeUpdate(explosionPos, dt)
	flashUpdate(explosionPos, dt)
	lightUpdate(explosionPos, dt)
end

function draw()

		    if GetString("game.player.tool") == "HaloFuelRod" and GetPlayerVehicle() == 0 then
	            UiPush()
		UiTranslate(UiCenter(), UiMiddle())
	            UiAlign("center middle")
		    UiColor(0, 1, 1, 2)
		    UiScale(1.5)
	            UiImage("MOD/Circle/ShotCircle.png")
		UiPop()
		end

		if GetString("game.player.tool") == "HaloFuelRod" and GetPlayerVehicle() == 0 then
		UiPush()
		    if InputDown("rmb") and not reloading then
	            UiTranslate(UiCenter(), UiMiddle())
	            UiAlign("center middle")
		UiColor(0, 1, 1, 0.8)
	            UiImage("MOD/Circle/ScopePic.png")
                    UiPop()
	        end
end

	if GetString("game.player.tool") == "HaloFuelRod" and GetPlayerVehicle() == 0 and not unlimitedammo then
		UiPush()
			UiTranslate(UiCenter(), UiHeight()-60)
			UiAlign("center middle")
			UiColor(1, 1, 1)
			UiFont("bold.ttf", 32)
			UiTextOutline(0,0,0,1,0.1)
			if reloading then
				UiText("Reloading")
			else
				UiText(ammo.."/"..1*math.max(0, mags-1))
			end
		UiPop()
	end
end