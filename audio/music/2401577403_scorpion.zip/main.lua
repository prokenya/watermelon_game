function init()
	RegisterTool("scorpion", "Scorpion", "MOD/vox/scorpion.vox")
	SetBool("game.tool.scorpion.enabled", true)
	SetFloat("game.tool.scorpion.ammo", 101)

	STATE_READY = 0
	STATE_THROWN = 1
	STATE_HOOKED = 2
	STATE_PULLING = 3
	state = STATE_READY

	punchpower = GetFloat("savegame.mod.punchpower")
	pullpower = GetFloat("savegame.mod.pullpower")
	if punchpower == 0 then punchpower = 100 end
	if pullpower == 0 then pullpower = 100 end
	velocity = 0.75
	gravity = Vec(0, 0, 0)
	swingTimer = 0
	pullTimer = 0

	line = {}
	line.active = false

	comeheresound = LoadSound("MOD/snd/comehere0.ogg")
	hitsound = LoadSound("MOD/snd/punch0.ogg")
	swingsound = LoadSound("MOD/snd/swing0.ogg")
	hooksound = LoadSound("MOD/snd/switch1.ogg")
end

function GetAimPos()
	local ct = GetCameraTransform()
	local forwardPos = TransformToParentPoint(ct, Vec(0, 0, -100))
    local direction = VecSub(forwardPos, ct.pos)
    local distance = VecLength(direction)
	local direction = VecNormalize(direction)
	local hit, hitDistance = QueryRaycast(ct.pos, direction, distance)
	if hit then
		forwardPos = TransformToParentPoint(ct, Vec(0, 0, -hitDistance))
		distance = hitDistance
	end
	return forwardPos, distance
end

function Punch()
	local forwardPos = TransformToParentPoint(GetCameraTransform(), Vec(0, 0, -1))
	local direction = VecSub(forwardPos, GetCameraTransform().pos)
	PlaySound(swingsound, GetPlayerTransform().pos, 0.6, false)
	QueryRequire("physical")
	local hit, dist, normal, shape = QueryRaycast(GetCameraTransform().pos, direction, 3)
	if hit then
		PlaySound(hitsound, GetPlayerTransform().pos, 0.75, false)
		local body = GetShapeBody(shape)
		if IsBodyDynamic(body) then
			local mass = GetBodyMass(body)
			local scale = mass > 1000 and punchpower/2 or punchpower*0.75
			local vel = VecScale(direction, 0.5)
			vel = VecScale(vel, scale)
			SetBodyVelocity(body, vel)
		end
	end
	swingTimer = 0.35
end

function Hook()
	local aimpos, dist = GetAimPos()
	local startPos = TransformToParentPoint(GetCameraTransform(), Vec(0.45, -0.15, -1))
	local direction = VecSub(aimpos, startPos)
	PlaySound(swingsound, GetPlayerTransform().pos, 0.75, false)

	line.gravity = gravity
	line.pos = VecCopy(startPos)
	line.predictedBulletVelocity = VecScale(direction, velocity*(100/dist))
end

function Pull()
	PlaySound(comeheresound, GetPlayerTransform().pos, 0.5, false)
	local s = InputDown("s")
	pullTimer = 0.45

	if IsBodyDynamic(hookbody) then
		local direction = VecSub(handPos, hookpos)
		local length = VecLength(direction)
		local mass = GetBodyMass(body)
		local pullpower = pullpower/100
		local shapes = GetBodyShapes(hookbody)
		
		local scale = 7
		if mass > 5000 then scale = 4
		elseif mass < 5000 then scale = 5
		elseif mass < 2500 then scale = 6
		elseif mass < 1000 then scale = 7 end
		local dirscale = 1 * (10/math.max(20, length))
		local vel = Vec(0, s and 7.5*dirscale or 2*dirscale, 0)

		vel = VecAdd(direction, vel)
		vel = VecScale(vel, scale*dirscale)
		vel = VecScale(vel, pullpower)
		SetBodyVelocity(hookbody, vel)
	else
		local dir = VecSub(hookpos, GetCameraTransform().pos)
		local length = VecLength(dir)
		local movepos = VecAdd(hookpos, Vec(0, length/5, 0))
		local movedir = VecSub(movepos, GetCameraTransform().pos)
		local dirscale = 1 * (10/math.max(20, length))
		local scale = length < 10 and math.max(10-length, 5) or 3
		local pullpower = pullpower/100
		
		movedir = VecScale(movedir, scale*dirscale)
		movedir = VecScale(movedir, pullpower)
		SetPlayerVelocity(movedir)
	end
end

function HookOperations(projectile)
	projectile.predictedBulletVelocity = VecAdd(projectile.predictedBulletVelocity, (VecScale(projectile.gravity, GetTimeStep())))
	local point2 = VecAdd(line.pos, VecScale(projectile.predictedBulletVelocity, GetTimeStep()))
	local dir = VecNormalize(VecSub(point2, line.pos))
	QueryRequire("physical")
	local hit, dist, normal, shape = QueryRaycast(line.pos, dir, VecLength(VecSub(point2, line.pos)))
	
	if hit then
		PlaySound(hooksound, GetPlayerTransform().pos, 0.75, false)
		hitPos = VecAdd(line.pos, VecScale(VecNormalize(VecSub(point2, line.pos)), dist))
		hookbody = GetShapeBody(shape)
		localhookpos = TransformToLocalPoint(GetBodyTransform(hookbody), hitPos)
		state = STATE_HOOKED
	else
		DrawLine(handPos, line.pos, 0, 0, 0)
	end

	line.pos = point2
end

function tick(dt)
	if GetString("game.player.tool") == "scorpion" and GetPlayerVehicle() == 0 then
		SetPlayerHealth(1)
		if InputPressed("lmb") then
			Punch()
		end
	
		if InputPressed("rmb") then
			if state == STATE_READY then
				line.active = true
				Hook()
				state = STATE_THROWN
			elseif state == STATE_HOOKED then
				Pull()
				state = STATE_READY
				line.active = false
			elseif state == STATE_THROWN then
				state = STATE_READY
				line.active = false
			end
		end

		local b = GetToolBody()
		if b ~= 0 then
			local offset = Transform(Vec(0, 0, 0), QuatEuler(10, 0, 0))
			SetToolTransform(offset)

			if swingTimer > 0 then
				local t = Transform()
				t.pos = Vec(0, 0, -swingTimer*3)
				t.rot = QuatEuler(swingTimer*20, 0, 0)
				SetToolTransform(t)

				swingTimer = swingTimer - dt
			end

			if pullTimer > 0 then
				local t = Transform()
				t.pos = Vec(0, 0, pullTimer*2)
				t.rot = QuatEuler(pullTimer*50, 0, 0)
				SetToolTransform(t)

				pullTimer = pullTimer - dt
			end
		end

		if line.active then
			handPos = TransformToParentPoint(GetCameraTransform(), Vec(0.35, -0.4, -2))
			if state == STATE_THROWN then
				HookOperations(line)
			elseif state == STATE_HOOKED then
				hookpos = TransformToParentPoint(GetBodyTransform(hookbody), localhookpos)
				DrawLine(handPos, hookpos, 0, 0, 0)
				DrawBodyOutline(GetShapeBody(hookbody), 0.5)
			end
		end
	end
end