function init()
	punchPower = GetFloat("savegame.mod.punchpower")
	if punchPower == 0 then punchPower = 100 end
	pullPower = GetFloat("savegame.mod.pullpower")
	if pullPower == 0 then pullPower = 100 end
end

function draw()
	UiTranslate(UiCenter(), 350)
	UiAlign("center middle")

	UiFont("bold.ttf", 48)
	UiText("Mortal Kombat Scorpion")
	UiFont("regular.ttf", 26)
	UiTranslate(0, 40)
	UiTranslate(0, 70)
	UiPush()
		UiText("Punch Power")
		UiAlign("right")
		UiTranslate(95, 40)
		punchPower = optionsSlider(punchPower, 30, 300)
		UiTranslate(-75, 20)
		UiColor(0.2, 0.6, 1)
		UiText(punchPower)
		SetFloat("savegame.mod.punchpower", punchPower)
	UiPop()

	UiTranslate(0, 110)
	UiPush()
		UiText("Hook Pull Power")
		UiAlign("right")
		UiTranslate(95, 40)
		pullPower = optionsSlider(pullPower, 30, 300)
		UiTranslate(-75, 20)
		UiColor(0.2, 0.6, 1)
		UiText(pullPower)
		SetFloat("savegame.mod.pullpower", pullPower)
	UiPop()

	UiButtonImageBox("ui/common/box-outline-6.png", 6, 6)

	UiTranslate(0, 120)
	if UiTextButton("Close", 80, 40) then
		Menu()
	end
end

function optionsSlider(val, min, max)
	UiColor(0.2, 0.6, 1)
	UiPush()
		UiTranslate(0, -8)
		val = (val-min) / (max-min)
		local w = 195
		UiRect(w, 3)
		UiAlign("center middle")
		UiTranslate(-195, 1)
		val = UiSlider("ui/common/dot.png", "x", val*w, 0, w) / w
		val = round((val*(max-min)+min), 2)
	UiPop()
	return val
end

function round(number, decimals)
    local power = 10^decimals
    return math.floor(number * power) / power
end